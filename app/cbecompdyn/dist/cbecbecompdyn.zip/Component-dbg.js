sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("cbe.cbecompdyn.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);